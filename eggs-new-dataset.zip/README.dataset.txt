# eggs-proj > 2024-04-23 10:52pm
https://universe.roboflow.com/eggs-odave/eggs-proj

Provided by a Roboflow user
License: CC BY 4.0

